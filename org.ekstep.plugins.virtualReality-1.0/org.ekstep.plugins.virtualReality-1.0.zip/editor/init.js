// Initialize the plugin namespace
org.ekstep.plugins = org.ekstep.plugins || {};
org.ekstep.plugins.virtualReality = {};
